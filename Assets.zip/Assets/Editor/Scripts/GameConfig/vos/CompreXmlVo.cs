﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mooji.Editor
{
    public class CompreXmlVo
    {
        public string filePath;
    }
}
