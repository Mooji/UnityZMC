﻿using UnityEngine;
using System.Collections;

public class AssetBundleInspectorObj : ScriptableObject 
{
	//Empty
}
