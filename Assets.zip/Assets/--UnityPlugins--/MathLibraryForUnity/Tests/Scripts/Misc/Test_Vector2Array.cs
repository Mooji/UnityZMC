﻿using UnityEngine;

namespace Dest.Math.Tests
{
	public class Test_Vector2Array : MonoBehaviour
	{
		public Vector2[] Array;
	}
}
