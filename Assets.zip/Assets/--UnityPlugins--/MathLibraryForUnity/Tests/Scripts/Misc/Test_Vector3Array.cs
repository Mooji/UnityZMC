﻿using UnityEngine;

namespace Dest.Math.Tests
{
	public class Test_Vector3Array : MonoBehaviour
	{
		public Vector3[] Array;
	}
}
